//
//  IntroductionViewController.swift
//  PersonalityQuiz
//
//  Created by Fariha Hussain on 6/7/20.
//  Copyright © 2020 PretendCo. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {

    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue){
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

