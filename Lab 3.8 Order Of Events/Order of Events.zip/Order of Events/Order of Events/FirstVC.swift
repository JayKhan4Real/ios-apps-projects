//
//  FirstVC.swift
//  Order of Events
//
//  Created by Fariha Hussain on 6/6/20.
//  Copyright © 2020 PretendCo. All rights reserved.
//

import UIKit

class FirstVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

